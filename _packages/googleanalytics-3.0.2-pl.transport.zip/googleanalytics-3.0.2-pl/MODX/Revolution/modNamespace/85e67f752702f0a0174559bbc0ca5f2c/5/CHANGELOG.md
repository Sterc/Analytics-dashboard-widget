----------------------
Google Analytics
----------------------

----------------------
Version: 3.0.2
Released: 2022-08-10
----------------------
- Refactored code to MODX3

----------------------
Version: 3.0.1-beta
Released: 2022-06-02
----------------------
- Fixed PHP warning: Optional parameter declared before required parameter

----------------------
Version: 3.0.0-beta
Released: 2021-12-13
----------------------
- Fix MODX 3 compatibility

----------------------
Version: 2.0.2-pl
Released: 2019-11-07
----------------------
- Github issue #30
- Github issue #26
- Github issue #20
- Github issue #32
- Some bugfixes and better caching
- Site speed added

----------------------
Version: 2.0.1-pl
Released: 2018-12-14
----------------------
- Widgets are installed via resolver

----------------------
Version: 2.0.0-pl
Released: 2017-09-13
----------------------
- Google Analytics Dashboard Widget can now be found under Extras > Google Analytics.
- Convert flash charts to html charts.
- Add widget that shows realtime visitors.
- Add widget that shows visitors and pageviews data.
- Add latest Google API changes.
- Add goals.
- Some bugfixes.

----------------------
Version: 1.1.0-pl
Released: 2015-09-17
----------------------
- Bugfixes
- New Google Auth
- New Real Time Visitors function
- Complete rebuild
    - New ExtJS and PHP code

----------------------
Version: 1.0.1-pl
Released: 2015-03-10
----------------------
- 404 Pages reporting

----------------------
Version: 1.0.0-pl
Released: 2014-09-25
----------------------
- First release
