<?php

use Sterc\GoogleAnalytics\Controllers\Base;

abstract class IndexManagerController extends Base
{

}
