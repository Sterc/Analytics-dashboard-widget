<?php

use Sterc\GoogleAnalytics\Controllers\Home;

class GoogleAnalyticsHomeManagerController extends Home
{

}
