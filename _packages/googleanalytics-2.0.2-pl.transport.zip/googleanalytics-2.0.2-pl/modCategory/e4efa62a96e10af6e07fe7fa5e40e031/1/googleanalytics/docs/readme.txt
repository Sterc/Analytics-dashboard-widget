----------------------
Google Analytics
----------------------
Version: 2.0.2-pl
Author: Oene Tjeerd de Bruin (Sterc)
Contact: modx@sterc.nl - https://www.sterc.com
----------------------