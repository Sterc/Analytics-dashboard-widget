----------------------
Google Analytics
----------------------
Version: 3.0.0-beta
Author: Oene Tjeerd de Bruin (Sterc)
Contact: modx@sterc.nl - https://www.sterc.com
----------------------