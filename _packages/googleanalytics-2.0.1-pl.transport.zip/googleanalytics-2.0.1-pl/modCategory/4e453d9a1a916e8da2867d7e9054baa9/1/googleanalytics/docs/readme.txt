----------------------
Google Analytics
----------------------
Version: 2.0.0-pl
Author: Oene Tjeerd de Bruin (Sterc)
Contact: modx@sterc.nl - https://www.sterc.com
----------------------

To use this component the user needs to have "googleanalytics" permissions.
The administrator user needs to have the "googleanalytics_settings" permissions.